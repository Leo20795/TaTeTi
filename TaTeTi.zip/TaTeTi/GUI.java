import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Image;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Font;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class GUI extends JFrame {
    //Logica de aplicacion
    private Logica l;
    //Paneles
    private JPanel panelTitulo;
    private JPanel panelJuego;
    //Botones
    private JButton [][] botones;
    //JLabels
    private JLabel titulo;
    private JLabel banner;
    //Constructor
    public GUI(){
        super("TaTeTi");
        l = new Logica();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(new Dimension(800,800));
        setLocationRelativeTo(null);    //Configuro para que la ventana se abra en el medio de la pantalla
        inicializarGUI();
        setVisible(true);
    }
    
    private void inicializarGUI(){
        this.setLayout(new GridBagLayout());
        //Configuracion del encabezado
        panelTitulo = new JPanel(new GridBagLayout());
        banner = new JLabel(new ImageIcon("banner.png"));
        panelTitulo.add(banner);
        GridBagConstraints gbc = new GridBagConstraints();  //Se crea un objeto para definir las restricciones de las componentes del GridBagLayout
        gbc.gridy = 0;  //Indica la fila que ocupa  
        gbc.weightx = 1;    //Indica como se distribuye el espacio en las columnas
        gbc.weighty = 0.2; // El panel superior será menos alto. Indica como se distribuye el espacio en las columnas
        gbc.fill = GridBagConstraints.BOTH; //El panel se redimensiona horizontal como verticalmente para ocupar todo el espacio disponible de su celda
        this.add(panelTitulo, gbc);
        //Configuracion del cuerpo
        panelJuego = new JPanel(new GridLayout(3,3));
        GridBagConstraints restriccionesCuerpo = new GridBagConstraints();
        restriccionesCuerpo.gridy = 1;
        restriccionesCuerpo.weighty = 1; //EL panel inferior sera mas alto
        restriccionesCuerpo.fill = GridBagConstraints.BOTH;
        this.add(panelJuego, restriccionesCuerpo);
        inicializarBotones();
        this.setResizable(false);
    }
    
    private void inicializarBotones(){
        botones = new JButton [3][3];
        ImageIcon blanco = new ImageIcon("blanco.jpg");
        Image imagenBlanca = blanco.getImage();
        Image imagenBlancaRedimensionada = imagenBlanca.getScaledInstance(250,200,Image.SCALE_SMOOTH);
        ImageIcon iconoBlancoRedimensionado = new ImageIcon(imagenBlancaRedimensionada);
        for(int f = 0; f < botones.length; f++){
            for(int c = 0; c < botones[0].length; c++){
                botones[f][c] = new JButton();
                botones[f][c].setEnabled(true);
                botones[f][c].setActionCommand(f+","+c);    //Identifico al boton con sus coordenadas
                botones[f][c].addActionListener(new OyenteBotonCelda());    //Se le asocia un oyente
                botones[f][c].setPreferredSize(new Dimension(500,500));
                botones[f][c].setIcon(iconoBlancoRedimensionado);
                panelJuego.add(botones[f][c]);
            }
        }
    }
    
    private class OyenteBotonCelda implements ActionListener {
        public void actionPerformed(ActionEvent e){
            String indices = e.getActionCommand(); //Obtengo el identificador del boton seleccionado
            String[] fc = indices.split(",");   //Cada vez que aparece una coma se divide el texto y se almacena en el arreglo fc
            int f=Integer.parseInt(fc[0]); //Obtengo nro de fila del boton
            int c=Integer.parseInt(fc[1]); //Obtengo nro de columna del boton
            if(!l.obtenerCelda(f,c)){
                //Impido que se presione un boton previamente presionado
                if(l.obtenerJugador()){
                    //Si presiono el jugador 1 
                    jugada1(f,c);
                    if(l.cantIntentos() > 4 && chequearGanador("X")){
                        JOptionPane.showMessageDialog(null, "Jugador 1 ha ganado!", "Información", JOptionPane.INFORMATION_MESSAGE);
                        resetear();
                    }
                }
                else{
                    //Si presiono el jugador 2
                    jugada2(f,c);
                    if(l.cantIntentos() > 4 && chequearGanador("O")){
                        JOptionPane.showMessageDialog(null, "Jugador 2 ha ganado!", "Información", JOptionPane.INFORMATION_MESSAGE);
                        resetear();
                    }
                }
            }
            if(l.cantIntentos() == 9 && !chequearGanador("X") && !chequearGanador("O")){
                JOptionPane.showMessageDialog(null, "Empate!", "Información", JOptionPane.INFORMATION_MESSAGE);
                resetear();
            }
        }
        
        private void jugada1(int f,int c){
            ImageIcon cruz = new ImageIcon("cruz.png");
            Image imagenCruz = cruz.getImage();
            Image imagenCruzRedimensionada = imagenCruz.getScaledInstance(250,200,java.awt.Image.SCALE_SMOOTH);
            ImageIcon iconRedimensionadox = new ImageIcon(imagenCruzRedimensionada);
            iconRedimensionadox.setDescription("X");
            botones[f][c].setIcon(iconRedimensionadox);
            l.seleccionarCelda(f,c);
            l.incrementarIntentos();
            l.cambiarJugador();
        }
        
        private void jugada2(int f,int c){
            ImageIcon circulo = new ImageIcon("circulo.png");
            Image imagenCirculo = circulo.getImage();
            Image imagenCirculoRedimensionada = imagenCirculo.getScaledInstance(250,200,Image.SCALE_SMOOTH);
            ImageIcon iconRedimensionado0 = new ImageIcon(imagenCirculoRedimensionada);
            iconRedimensionado0.setDescription("O");
            botones[f][c].setIcon(iconRedimensionado0);
            l.seleccionarCelda(f,c);
            l.incrementarIntentos();
            l.cambiarJugador();
        }
        
        private boolean chequearGanador(String jugador){
            int contador = 0;
            boolean paro;
            Icon iconoBoton;
            String nombreIcono;
            String nombreA = "Z";
            String nombreB = "Z";
            String nombreC = "Z";
            //Recorro por filas
            for(int f = 0; f < l.cantFilas() && contador < 3 ; f++){
                paro = false;
                for(int c = 0; c < l.cantColumnas() && !paro && l.obtenerCelda(f,c); c++){
                    iconoBoton = botones[f][c].getIcon();
                    nombreIcono = ((ImageIcon) iconoBoton).getDescription();    //Obtengo el identificador del boton
                    if(nombreIcono.equals(jugador)){
                        contador++;
                    }
                    else{
                        contador = 0;
                        paro = true;
                    }
                }
            }
            //Recorro por columnas (en caso de ser necesario)
            if(contador != 3){
                contador = 0;
                for(int c = 0; c < l.cantColumnas() && contador < 3; c++){
                    paro = false;
                    contador = 0;
                    for(int f = 0; f < l.cantFilas() && l.obtenerCelda(f,c) && !paro; f++){
                        iconoBoton = botones[f][c].getIcon();
                        nombreIcono = ((ImageIcon) iconoBoton).getDescription();
                        if(nombreIcono.equals(jugador)){
                            contador++;
                        }
                        else{
                            contador = 0;
                            paro = true;
                        }    
                    }
                }
            }
            //Recorro las diagonales (en caso de ser necesario)
            if(contador != 3){
                //Si las celdas estan presionadas
                if(l.obtenerCelda(0,0) && l.obtenerCelda(1,1) && l.obtenerCelda(2,2)){
                    iconoBoton = botones[0][0].getIcon();
                    nombreA = ((ImageIcon) iconoBoton).getDescription();
                    iconoBoton = botones[1][1].getIcon();
                    nombreB = ((ImageIcon) iconoBoton).getDescription();
                    iconoBoton = botones[2][2].getIcon();
                    nombreC = ((ImageIcon) iconoBoton).getDescription();
                    if(nombreA.equals(jugador) && nombreB.equals(jugador) && nombreC.equals(jugador)){
                        contador = 3;
                    }
                }
                //Recorro la otra diagonal si estan presionadas sus celdas correspondientes
                else if(l.obtenerCelda(0,2) && l.obtenerCelda(1,1) && l.obtenerCelda(2,0)){
                    iconoBoton = botones[0][2].getIcon();
                    nombreA = ((ImageIcon) iconoBoton).getDescription();
                    iconoBoton = botones[1][1].getIcon();
                    nombreB = ((ImageIcon) iconoBoton).getDescription();
                    iconoBoton = botones[2][0].getIcon();
                    nombreC = ((ImageIcon) iconoBoton).getDescription();
                    if(nombreA.equals(jugador) && nombreB.equals(jugador) && nombreC.equals(jugador)){
                        contador = 3;
                    }
                }
            }
            return contador == 3;
        }
        private void resetear(){
            l.resetearMatriz();
            l.resetearJugador();
            l.resetearIntentos();
            ImageIcon blanco = new ImageIcon("blanco.jpg");
            Image imagenBlanca = blanco.getImage();
            Image imagenBlancaRedimensionada = imagenBlanca.getScaledInstance(250,200,Image.SCALE_SMOOTH);
            ImageIcon iconoBlancoRedimensionado = new ImageIcon(imagenBlancaRedimensionada);
            for(int f = 0; f < l.cantFilas(); f++){
                for(int c = 0; c < l.cantColumnas(); c++){
                    botones[f][c].setIcon(iconoBlancoRedimensionado);
                }
            }
        }
    }
}
