public class Principal {
    public static void main (String [] args){
        GUI g = new GUI();
    }
}
