public class Logica {
    //Atributos de instancia
    protected boolean [][] celdas;
    protected boolean jugador;
    protected int intentos;
    //Constructor
    public Logica (){
        celdas = new boolean [3][3];
        for(int f = 0; f < celdas.length; f++){
            for(int c = 0; c < celdas[0].length; c++){
                celdas[f][c] = false;
            }
        }
        jugador = true; //true representa jugador 1
        intentos = 0;
    }
    //Consultas
    public int cantFilas(){
        return celdas.length;
    }
    public int cantColumnas(){
        return celdas[0].length;
    }
    public boolean obtenerCelda(int f,int c){
        return celdas[f][c];
    }
    public boolean obtenerJugador(){
        return jugador;
    }
    public int cantIntentos(){
        return intentos;
    }
    //Comandos
    public void seleccionarCelda(int f,int c){
        celdas[f][c] = true;
    }
    public void incrementarIntentos(){
        intentos++;
    }
    public void cambiarJugador(){
        jugador = !jugador;
    }
    public void resetearMatriz(){
        for(int f = 0; f < celdas.length; f++){
            for(int c = 0; c < celdas[0].length; c++){
                celdas[f][c] = false;
            }
        }
    }
    public void resetearIntentos(){
        intentos = 0;
    }
    public void resetearJugador(){
        jugador = true;
    }
}